import express from "express";
import passport from "../config/passport.js";

import {
  handleLogin,
  handleVerifyToken,
  googleCallback,
  githubCallback,
  requestPasswordReset,
  resetPassword,
} from "../controller/auth-controller.js";
import { verifyAccessToken } from "../middleware/basic-access-control.js";

const router = express.Router();

router.post("/login", handleLogin);
router.post("/forgot-password", requestPasswordReset);
router.post("/reset-password", resetPassword);

router.get("/verify-token", verifyAccessToken, handleVerifyToken);

// Google OAuth
router.get("/google", passport.authenticate("google", { scope: ["profile", "email"] }));

router.get(
  "/google/callback",
  passport.authenticate("google", { session: false, failureRedirect: "/" }),
  googleCallback
);

// GitHub OAuth
router.get("/github", passport.authenticate("github", { scope: ["user:email"] }));

router.get(
  "/github/callback",
  passport.authenticate("github", { session: false, failureRedirect: "/" }),
  githubCallback
);


export default router;
